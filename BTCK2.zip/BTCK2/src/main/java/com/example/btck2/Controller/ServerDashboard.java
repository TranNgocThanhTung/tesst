

package com.example.btck2.Controller;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import java.awt.event.ActionListener;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

public class ServerDashboard implements Initializable {
    @FXML
    private TextField portSV;
    @FXML
    private Button btnStartSV;
    @FXML
    private Button btnStop;
    @FXML
    private TextArea textareaSV;

    private ServerSocket serverSocket;
    private Thread serverThread;
    private Client client;
    private Map<String,Socket> connectedClients;

    private static final String UPLOAD_DIR = "uploads";  // Thư mục để lưu file tải lên

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        portSV.setText("");
        textareaSV.setEditable(false);
        connectedClients = new HashMap<>();
    }

    public String getPortSV() {
        return portSV.getText();
    }

    @FXML
    public void startServer(ActionEvent actionEvent) {
        int port;
        try {
            port = Integer.parseInt(portSV.getText());
        } catch (NumberFormatException e) {
            textareaSV.appendText("Invalid port number.\n");
            return;
        }

        serverThread = new Thread(() -> {
            try {
                serverSocket = new ServerSocket(port);
                Platform.runLater(() -> {
                    textareaSV.appendText("Server started on port " + port + "\n");
                    btnStartSV.setDisable(true);
                    btnStop.setDisable(false);
                });

                while (!serverSocket.isClosed()) {
                    Socket clientSocket = serverSocket.accept();
                    Platform.runLater(() -> textareaSV.appendText("Client connected: " + clientSocket.getInetAddress() + "\n"));
                }
            } catch (IOException e) {
                Platform.runLater(() -> textareaSV.appendText("Error starting server: " + e.getMessage() + "\n"));
            }
        });
        serverThread.start();
    }
    @FXML
    public void stopServer(ActionEvent actionEvent) {
        try {
            if (serverSocket != null && !serverSocket.isClosed()) {
                serverSocket.close();
                Platform.runLater(() -> {
                    textareaSV.appendText("Server stopped.\n");
                    btnStartSV.setDisable(false);
                    btnStop.setDisable(true);
                });
            }
        } catch (IOException e) {
            Platform.runLater(() -> textareaSV.appendText("Error stopping server: " + e.getMessage() + "\n"));
        }
    }



    private class ClientHandler implements Runnable {
        private Socket clientSocket;

        public ClientHandler(Socket clientSocket) {
            this.clientSocket = clientSocket;
        }

        @Override
        public void run() {
            try (DataInputStream dis = new DataInputStream(clientSocket.getInputStream())) {
                String clientName = dis.readUTF();
                connectedClients.put(clientName, clientSocket);
                Platform.runLater(() -> textareaSV.appendText("Client connected: " + clientName + "\n"));

                while (true) {
                    String recipientName = dis.readUTF();
                    String fileName = dis.readUTF();
                    long fileLength = dis.readLong();

                    byte[] buffer = new byte[4096];
                    int bytesRead;
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    long remaining = fileLength;

                    while ((remaining > 0) && (bytesRead = dis.read(buffer, 0, (int) Math.min(buffer.length, remaining))) != -1) {
                        baos.write(buffer, 0, bytesRead);
                        remaining -= bytesRead;
                    }

                    if (connectedClients.containsKey(recipientName)) {
                        Socket recipientSocket = connectedClients.get(recipientName);
                        DataOutputStream dos = new DataOutputStream(recipientSocket.getOutputStream());

                        dos.writeUTF(fileName);
                        dos.writeLong(fileLength);
                        dos.write(baos.toByteArray());

                        Platform.runLater(() -> textareaSV.appendText("File sent to: " + recipientName + "\n"));
                    } else {
                        Platform.runLater(() -> textareaSV.appendText("Client " + recipientName + " not found.\n"));
                    }
                }
            } catch (IOException e) {
                Platform.runLater(() -> textareaSV.appendText("Client disconnected: " + e.getMessage() + "\n"));
            }
        }
    }

}


