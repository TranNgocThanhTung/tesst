package com.example.btck2.Controller;

import com.example.btck2.Model.connectDB;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.StageStyle;


import java.io.*;
import java.net.Socket;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;




public class Client  implements Initializable {
    private Connection con;
    @FXML
    private TextField clientname;
    @FXML
    public TextField port;
    @FXML
    private Button btnconnect;
    @FXML
    private TextArea TACL;
@FXML
private Button sf;
    @FXML
    private TextField lbcf;
   @FXML
   private TextField send;

    private List<File> selectedFiles;
    private Socket socket;
    private ServerDashboard serverDashboard;
    private int portNumber;
    private DataOutputStream dos;

    public String getCLN() {
        return clientname.getText();
    }

    private Alert alert;

    public void setServerDashboard(ServerDashboard serverDashboard) {
        this.serverDashboard = serverDashboard;
    }


    @FXML
    public void connect(ActionEvent actionEvent) {

        try {
            portNumber = Integer.parseInt(port.getText());

        } catch (NumberFormatException e) {
            showAlert("Invalid Port", "Please enter a valid port number.");
            return;
        }

        new Thread(() -> {
            try (Socket socket = new Socket("localhost", portNumber)) {
                dos = new DataOutputStream(socket.getOutputStream());
                Platform.runLater(() -> {
                    TACL.appendText("Connect successful\n");
                });
            } catch (IOException e) {
                Platform.runLater(() -> showAlert("Connection Failed", "Could not connect to server on port " + portNumber + "."));
            }

        }).start();
    }

    private void showAlert(String title, String message) {
        alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        if (TACL != null) {
            TACL.setEditable(false);
        }
    }


    @FXML
    public void choosefile(ActionEvent actionEvent) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Files");

        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
         selectedFiles = fileChooser.showOpenMultipleDialog(stage);

        if (selectedFiles != null) {
            for (File file : selectedFiles) {
                System.out.println("Selected file: " + file.getAbsolutePath());
            }
            String fileNames = selectedFiles.stream()
                    .map(File::getName)
                    .collect(Collectors.joining(", "));
            lbcf.setText(fileNames);
        }
    }
    @FXML
    public void sendFile(ActionEvent actionEvent) {
        if (selectedFiles == null || selectedFiles.isEmpty()) {
            showAlert("No File Selected", "Please select a file to send.");
            return;
        }

        String recipientEmail = send.getText();
        if (recipientEmail.isEmpty()) {
            showAlert("No Recipient", "Please enter the recipient's email.");
            return;
        }
        boolean isValidEmail = checkEmailValidity(recipientEmail);
        if (!isValidEmail) {
            showAlert("Invalid Recipient", "The recipient's email is not valid.");
            return;
        }
        new Thread(() -> {
            try {
                for (File file : selectedFiles) {
                    FileInputStream fis = new FileInputStream(file);

                    // Send recipient email
                    dos.writeUTF(recipientEmail);

                    // Send file name and length
                    dos.writeUTF(file.getName());
                    dos.writeLong(file.length());

                    // Send file data
                    byte[] buffer = new byte[4096];
                    int bytesRead;
                    while ((bytesRead = fis.read(buffer)) != -1) {
                        dos.write(buffer, 0, bytesRead);
                    }

                    fis.close();
                }
                Platform.runLater(() -> TACL.appendText("Files sent successfully\n"));
            } catch (IOException e) {
                Platform.runLater(() -> showAlert("File Transfer Failed", "Could not send the file(s)."));
            }
        }).start();
    }
    public boolean checkEmailValidity(String email) {
        con= connectDB.connect();
        boolean isValid = false;
        String query = "SELECT COUNT(*) FROM user WHERE email = ?";
        try (PreparedStatement statement = con.prepareStatement(query)) {
            statement.setString(1, email);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    int count = resultSet.getInt(1);
                    // Nếu có ít nhất một hàng trả về, email hợp lệ
                    isValid = count > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();

        }
        return isValid;
    }
}
